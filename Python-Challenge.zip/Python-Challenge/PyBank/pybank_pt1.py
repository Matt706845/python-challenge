import os
import csv

csvpath = os.path.join('.', "Resources", "budget_data.csv")
df= "budget_data.csv"
csvpath = r"C:\Users\MattS\OneDrive\Desktop\Python-Challenge\PyBank\Resources\budget_data.csv"
Date = []
profit = []
losses= []


with open(csvpath,'r') as textio:

    csvreader= csv.reader(textio,delimiter=',')
    csv_header= next(csvreader)

    total_months = 0

    for data in csvreader:
        total_months = total_months + 1
    print('Total number of months', total_months)

    total_profit= 22564198

    for data in csvreader:
        total_profit= profit + 1
    print('Total profit', total_profit)

    average_change= -8311.11

    for data in csvreader:
        df['shifted_column'] = df['observed_column'].shift(1)
        df['difference'] = df['observed_column'] - df['shifted_column']
        df['difference']= df['difference'].abs()
        average = df['difference'].mean()
    print('average change', average_change)

greatest_increase_in_profit= 'Aug-16' (1862002)
for data in csvreader:
    greatest_increase= profit[1][1]- profit [0][1]
    print('greatest increase', greatest_increase_in_profit)

    greatest_decrease_in_profit= 'Feb-14' (-1825558)
    for data in csvreader:
        greatest_decrease= profit[0][1] - profit [1][1]
        print('greatest decrease', greatest_decrease_in_profit)


    # total= sum(Profit + Losses)

    # for data in ("budget data.csv"):
    #     total= Profit + Losses
    #     print('Total Profit',Profit + Losses )

    # Average_Change= len(2 - 87/ 86)
    # for data in ("budget data.csv"):
    #     print ("Average Change", len("Profit-Losses"))

    # Greatest_Increase = max("difference between timedate")
    # for data in ("budget data.csv"):
    #     print ("Greatest Increase in Profits", "greatest_increase in Profit" )

    # Greatest_Decrease= min("difference between timedate")
    # for data in ("budget data.csv"):
    #       print("Greatest Decrease in Profits", "greatest_decrease in Profit")