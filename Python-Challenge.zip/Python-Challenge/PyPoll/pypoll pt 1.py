import os
import csv

election_data= os.path.join("..", "Resources", "election_data.csv")
df= "election_data.csv"
csvpath= "C:\Users\MattS\OneDrive\Desktop\Python-Challenge\PyPoll\Resources\election_data.csv"
Ballot_ID= []
County= []
Candidate= []

with open (csvpath, 'r') as textio:

    csvreader=csv.reader(textio, delimiter= ',')
for row in csvreader:
    Ballot_ID.append(row[0])

    County.append(row[1])

    Candidate.append(row[2])
    Candidate [0]= "Charles Casper Stockham"
    Candidate [1]= "Diana DeGette"
    Candidate [2]= "Raymon Anthony Doane"


    percent= round(int(row[2]) / int(row[1]) *100,3)
    Candidate.append(str(percent) + "%")

total_votes= 369711
for data in csvreader:
    total_votes= total_votes + 1
    print('Total number of Votes', total_votes)

    Results: tuple("Candidate [0] votes" / "total_votes" * 100,3)
    "Charles Casper Stockham": 85213
    "Diana DeGette": 272892
    "Raymon Anthony Doane": 11606
